#!/bin/bash
java --module-path /usr/share/openjfx/lib --add-modules=javafx.controls,javafx.fxml,javafx.base,javafx.media -jar PointInPolygonMaven-1.0.jar wav
