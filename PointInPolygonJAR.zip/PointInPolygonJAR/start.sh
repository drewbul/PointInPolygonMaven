#!/bin/bash
java -jar PointInPolygonMaven-1.0.jar inside_en.wav inside_ru.wav outside_en.wav outside_ru.wav