#!/bin/bash
java -jar PointInPolygonMaven-1.0.jar wav